

function clearErrors() {
    var errors = document.getElementsByClassName('formerror');
    for (let item of errors) {
      item.innerHTML = "";
    }
  }
   
  function seterror(id, error) {  // jo bhi error dega wo is id ke andar daal dega
    var element = document.getElementById(id);
    element.getElementsByClassName('formerror')[0].innerHTML = error;
  }
   
  function validateForm() {
    var returnval = true;
    clearErrors();
    var name = document.forms['myForm']["fname"].value;  //document.form saare ke saare form ko lr aata hai  mujhe wo form dedo jiska naam myForm hai aur jiska name fname h uski value dedo
    var email = document.forms['myForm']["femail"].value;
    var phone = document.forms['myForm']["fphone"].value;
    var password = document.forms['myForm']["fpass"].value;
    var cpassword = document.forms['myForm']["fcpass"].value;

    // document.write(email);
    // if ( name.length < 5) {
    //   seterror("name", "*Name should start with an uppercase letter and be at least 5 characters long!");
    //   returnval = false;
    // }
   
  
   
    if (email.length > 15) {
      seterror("email", "*Email length is too long");
      returnval = false;
    }
   
    if (phone.length != 10 || !/^\d+$/.test(phone)) {
      seterror("phone", "*Phone number should be of 10 digits and not contain alphabets!");
      returnval = false;
    }
   
    if (password.length < 6 || !/(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]/.test(password)) {
      seterror("pass", "*Password should be at least 6 characters long and contain one letter, one number, one special character, and one uppercase letter!");
      returnval = false;
    }
   
    if (cpassword != password) {
      seterror("cpass", "*Password and Confirm password should match!");
      returnval = false;
    }


    if(returnval){
      var formData = {
        firstName : name,
        lastName: name,
        email: email,
        phone: phone
      };

      localStorage.setItem("formData" , JSON.stringify(formData));
    }
    return returnval;
  }

  



  function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah')
                .attr('src', e.target.result)
                .width(100)
                .height(100);
        };

        reader.readAsDataURL(input.files[0]);
    }
}

















