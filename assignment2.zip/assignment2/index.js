    document.getElementById('main-form').addEventListener('submit', function (event) {
        event.preventDefault();
 
        var isValid = validateForm();
 
        if (isValid) {
            successMessage();
            clearForm();

            setTimeout(function(){
                document.getElementById('success-message').remove();
            },3000);

        } else {
            errorMessageDiv();

            setTimeout(function(){
                document.getElementById('error-message').remove();
            },3000);
        }
    });
 
    function validateForm() {
        var isValid = true;
        var firstName = document.getElementsByName('fname')[0].value;
        var lastName = document.getElementsByName('lname')[0].value;
        var username = document.getElementsByName('fusername')[0].value;
        var password = document.getElementsByName('fpass')[0].value;
        var confirmPassword = document.getElementsByName('fcpass')[0].value;
        var email = document.getElementsByName('femail')[0].value;
        var phone = document.getElementsByName('fphone')[0].value;

 
 
    
        if (!/^[a-zA-Z#$]+$/.test(firstName) || firstName.length < 5 || firstName.length > 15) {
            isValid = false;
            document.getElementById('name1').querySelector('.formerror').textContent = 'First name should contain only alphabets and special characters (#,$) and should be between 5 and 15 characters long.';
        } else {
            clearError('name1');
        }
 
        if (!/^[a-zA-Z#$]+$/.test(lastName) || lastName.length > 10) {
            isValid = false;
            document.getElementById('name2').querySelector('.formerror').textContent = 'Last name should contain only alphabets and special characters (#,$) and should not exceed 10 characters.';
        } else {
            clearError('name2');
        }
 
        if (!/^[a-zA-Z0-9]+$/.test(username) || username.length > 10) {
            isValid = false;
            document.getElementById('username').querySelector('.formerror').textContent = 'Username should contain only alphanumeric characters and should not exceed 10 characters.';
        } else {
            clearError('username');
        }
 
        if (password !== confirmPassword) {
            isValid = false;
            document.getElementById('pass').querySelector('.formerror').textContent = 'Passwords do not match.';
            document.getElementById('cpass').querySelector('.formerror').textContent = 'Passwords do not match.';
        } else {
            clearError('pass');
            clearError('cpass');
        }
 
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            isValid = false;
            document.getElementById('email').querySelector('.formerror').textContent = 'Invalid email address.';
        } else {
            clearError('email');
        }
 
        if (!/^+91[0-9]{10}$/.test(phone)) {
            isValid = false;
            document.getElementById('phone').querySelector('.formerror').textContent = 'Invalid phone number. Phone number should start with "+91" and contain only numbers.';
        } else {
            clearError('phone');
        }
 
        return isValid;
    }
 
   
    function clearError(fieldId) {
        document.getElementById(fieldId).querySelector('.formerror').textContent = '';
    }
 
    function successMessage() {
        var message = document.createElement('div');
        message.textContent = 'We have successfully submitted the form.';
        message.style.color = 'green';
        message.id ='success-message';
        document.getElementById('main-form').insertBefore(message, document.getElementById('main-form').firstChild);
    }
 
    function clearForm() {
        document.getElementById('main-form').reset();
    }

 
    function errorMessageDiv() {
        var errorMessage = document.createElement('div');
        errorMessage.textContent = 'We are unable to process the request.';
        errorMessage.style.color = 'red';
        errorMessage.id = 'error-message';
        document.getElementById('main-form').insertBefore(errorMessage, document.getElementById('main-form').firstChild);
    }





