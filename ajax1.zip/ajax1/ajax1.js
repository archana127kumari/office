// // $.ajax({
// //     url: "https://restcountries.com/v3.1/all?fields=name,flags",
// //     success:  function(data){
// //         console.log(data);
// //        $("#output").html("<pre>" + JSON.stringify(data,null,2) + "<pre>");

// //     }
// // });




$.ajax({
    url: "https://restcountries.com/v3.1/all?fields=name,flags",
        success: function(data) {
            if (data.length > 0) {
                data.forEach(function(country) {
                    var countryName = country.name.common;
                    var flagUrl = country.flags.png;
                    var countryCommonName = country.name.official;
                    
                    var htmlContent = "<div class='country'>";
                    htmlContent += "<img src='" + flagUrl + "' alt='" + countryName + " Flag'>";
                    htmlContent += "<h1>" + countryCommonName + "</h1>";

                    htmlContent += "<h2>" + countryName + "</h2>";

                    htmlContent += "</div>";
     
                    $("#output").append(htmlContent);
                });
            } else {
                $("#output").html("No country data available.");
            }
        },
        error: function(xhr, status, error) {
            console.error(xhr, status, error);
            $("#output").html("An error occurred while fetching data.");
        }
    });