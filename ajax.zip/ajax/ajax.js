console.log("hiii, How are you");

let fetchBtn = document.getElementById('fetchBtn');

fetchBtn.addEventListener('click', buttonClickHandler)

function buttonClickHandler(){

    console.log("you have clicked the button fetchBtn");

    //instantiate an xhr object
    const xhr = new XMLHttpRequest();

    //open the object
    //true is for asynchronos
    xhr.open('GET' , 'page.txt' , true);
    //What to do on progress(optional)

    xhr.onprogress = function(){
        console.log("On progress");
    }
    //what to do when response is ready

    xhr.onload = function(){
        if(this.status === 200){    // 200 is http code that represents ok
        console.log(this.responseText)
        }
        else{
            console.error("error occured");
        }
    }
    
    //send request
    xhr.send();

}






///////////////////////////////////////Cookies///////////////////////////////////////////////


//   cookies are used to store data directly in browser 